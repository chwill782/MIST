require_relative 'apis/resource_base'
