require 'site_prism'

module Common
  class BaseSection < SitePrism::Section

    include Common
  end
end
